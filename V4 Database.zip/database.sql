-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2020 at 06:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `linkshied`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(11) NOT NULL,
  `ads1` varchar(600) NOT NULL,
  `ads2` varchar(600) NOT NULL,
  `ads3` varchar(600) NOT NULL,
  `ads4` varchar(500) NOT NULL,
  `ads5` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `ads1`, `ads2`, `ads3`, `ads4`, `ads5`) VALUES
(1, '<!-- your ad code here -->', '<!-- your ad code here -->', '<!-- your ad code here -->', '<!-- your ad code here -->', '<!-- your ad code here -->');

-- --------------------------------------------------------

--
-- Table structure for table `ads_click`
--

CREATE TABLE `ads_click` (
  `id` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `earn_transactions`
--

CREATE TABLE `earn_transactions` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `link_id` varchar(200) NOT NULL,
  `get_id` varchar(200) NOT NULL,
  `remove_id` varchar(200) NOT NULL,
  `urls` longtext NOT NULL,
  `pass` varchar(3) NOT NULL,
  `password` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `captcha` varchar(5) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `page_name` text NOT NULL,
  `page_data` longtext NOT NULL,
  `page_st` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `page_name`, `page_data`, `page_st`) VALUES
(1, 'PRIVACY POLICY', '<p>This site\'s policy is to respect and protect the privacy of our users. We at This site respect your privacy. All information collected at This site is kept confidential and will not be sold, resued, or rented in any way. We do not share your infromation with any 3rd parties.</p>\r\n<strong>IP Addresses:</strong>\r\n<p>IP addresses are logged by This site to ensure account safety features availability, measuring usage and statistics.</p>\r\n \r\n<strong>Email Addresses:</strong>\r\n<p>We collect email addresses of users at the time of registration as means of contact and verification. This site does not rent, sell, or share your email addresses with anyone.</p>\r\n \r\n<strong>Your account username and password:</strong>\r\n<p>Please note that it is your responsibility to keep the username and password confidential, so do not share it with anyone. If you use a public PC, make sure you log out prior to leaving This site site. You are solely responsible for keeping your username/password inviolable.</p>\r\n \r\n<strong>Certain Exceptional Disclosures:</strong>\r\n<p>We may disclose your information if necessary to protect our legal rights or if the information relates to actual or threatened harmful conduct or potential threats to the physical safety of any person. The disclosure of personal information may be required by court or law enforcement officials.</p>\r\n \r\n<strong>Use of Cookies:</strong>\r\n<p>This site uses cookies in order to track and analyze preferences of our users and, as a result, improve our site. A cookie is an encrypted number, generated when you visit any site that supports sessions. This cookie is saved permanently on your computer. This data does not contain any secure information (just an encrypted string). Additionally, we set a cookie when you log in to make further logging into our system a little easier. No other website can access any information about you from the cookies we may store on your local computer. We do not share cookies or any other type of information with any other companies. You can always choose not to receive a cookie file by enabling your web browser to refuse cookies or to prompt you before accepting a cookie.</p>\r\n \r\n<strong>Third party cookies:</strong>\r\n<p>In case of serving advertisements to this site, our third-party advertiser may place or recognize a unique cookie on your browser.</p>\r\n \r\n<strong>External links:</strong>\r\n<p>If any part of the This site website links you to other websites, those websites do not operate under this Privacy Policy. We recommend you examine the privacy statements posted on those other websites to understand their procedures for collecting, using and disclosing personal information.</p>\r\n \r\n<strong>Changes to Privacy Policy:</strong>\r\n<p>We reserve the right, at any time and without notice, to add to, change, update, or modify this Privacy Policy. Any change, update, or modification will be effective immediately upon posting on the site. Please check this page periodically for changes.</p>', 'on'),
(2, 'TERMS', '<strong>General:</strong>\r\n<p>This site is a free service that helps users to protect links from inconvenient people or automated robots with security such as captcha and password. This This site service agreement (the \"Agreement\") describes the terms and conditions on which This site (\"we\") offer services to you (\"User\"). By using our services, User agrees to be bound by the following terms and conditions:<p>\r\n\r\n\r\n<strong>Conditions for Use:</strong>\r\n<p>Do not try to abuse or cheat our system. We reserve the right to delete and banned your account without any warning if we will be suspicious for abuse.</p>\r\n\r\n<strong>(A) It is prohibited to upload content-</strong>\r\n<p>Which violates the applicable Criminal Laws such as Child Pornography\r\nWhich infringe upon the copyright, patent or intellectual property rights.</p>\r\n\r\n<strong>(B) The uses of the service-</strong>\r\n<p>May not use the service to access or distribute illegal or immoral content.<br/>\r\nMay not use the service to incite or participate in criminal acts. Likewise, instructions for the committing of criminal acts may not be expressed or published in any form or manner.<br/>\r\nMay not disseminate content which is harassing, defamatory, obscene, racist, glorifying of violence, discriminatory, pornographic or threatening.<br/>\r\nMay not abuse the system resources.<br/>\r\nUsers must agree to comply with all laws which apply to their location, including copyright and trademark laws. Images, videos and files that violate copyrights or trademarks are not allowed. If someone has an infringement claim against you, we will remove that reported user and link from our site.</p>\r\n \r\n<strong>Responsibility for user account information:</strong>\r\n<p>The user holds full responsibility for keeping the account information safe and confidential (as well as authorized user\'s account information). The user is also entirely responsible for all the actions carried out via his/her account.</p>\r\n \r\n<strong>Modifications to Terms of Service:</strong>\r\n<p>This site reserves the right to change any of these terms and services at any time.</p>\r\n \r\n<strong>No Resale of the Service:</strong>\r\n<p>Member\'s right to use the Service is personal to Member. Member agrees not to resell the Service without the express consent of This site.</p>\r\n\r\n\r\n<strong>We reserve the rights to take action:</strong>\r\n<p>This site reserves the right to block and/or delete immediately any dubious files or those that include clear violations of law or are immoral.<br/>\r\nThis site reserves the right to refuse any submitted content without giving cause.<br/>\r\nThis site does not tolerate illegal content and expressly states that all files with illegal content will be deleted immediately after that fact becomes known to This site and technical measures will be taken to prevent an attempt at protecting the content again.</p>\r\n\r\n\r\n<strong>Backup Your Content:</strong>\r\n<p>The user is responsible for the backing up (to his own computer or other devices) of the files (urls) that he stores or accesses on This site\'s servers. This site does not guarantee or warrant that any content that the user saves, stores or accesses through the service will not be subject to inadvertent damage or loss.</p>', 'on'),
(3, 'About Us', '=== HTML CODE HERE ====', 'on'),
(4, 'Contact Us', '=== HTML CODE HERE ====', 'on'),
(5, 'Disclaimer', '=== HTML CODE HERE ====', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `pay_methods`
--

CREATE TABLE `pay_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pay_methods`
--

INSERT INTO `pay_methods` (`id`, `name`) VALUES
(1, 'Paytm'),
(2, 'PayPal');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_name` varchar(200) NOT NULL,
  `symbol` varchar(200) NOT NULL,
  `payout_limit` varchar(20) NOT NULL,
  `earn_limit` varchar(20) NOT NULL,
  `re_key` varchar(200) NOT NULL,
  `re_s_key` varchar(200) NOT NULL,
  `ref_user` varchar(50) NOT NULL,
  `reg_user` tinyint(1) NOT NULL,
  `captcha` tinyint(1) NOT NULL,
  `skip_timer` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `symbol`, `payout_limit`, `earn_limit`, `re_key`, `re_s_key`, `ref_user`, `reg_user`, `captcha`, `skip_timer`) VALUES
(1, 'LinkShield', '$', '20', '1', '6LfzhHAUAAAAAEu0_GCyBktnKKhDrjqm2JXZUxS6', '6LfzhHAUAAAAAEIsNYN3SIXZDZAV1vXPVJBoTyrR', '5', 1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `amount`, `date`, `status`) VALUES
(1, '1', '500', '2020-03-29', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `wallet` varchar(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL,
  `ref` varchar(10) NOT NULL,
  `pay_method` varchar(200) NOT NULL,
  `details` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `views`
--

CREATE TABLE `views` (
  `id` int(11) NOT NULL,
  `link_id` varchar(20) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `ip_add` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ads_click`
--
ALTER TABLE `ads_click`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `earn_transactions`
--
ALTER TABLE `earn_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_methods`
--
ALTER TABLE `pay_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ads_click`
--
ALTER TABLE `ads_click`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `earn_transactions`
--
ALTER TABLE `earn_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pay_methods`
--
ALTER TABLE `pay_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `views`
--
ALTER TABLE `views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
