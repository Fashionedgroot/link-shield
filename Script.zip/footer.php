 <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <p>Give Review at<a href="http://codester.com/rohitchouhan" class="text-dark" target="_blank">Codester</a></p>
                        </div>
                    </div>
                </footer>
            </div>